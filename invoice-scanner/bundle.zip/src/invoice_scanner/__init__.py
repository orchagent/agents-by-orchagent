"""Invoice scanner agent package."""
