#!/usr/bin/env python3
"""
Code Stats Agent - Entry point for E2B sandbox execution.

Input (stdin JSON):
{
  "code": "def hello():\n    print('hi')\n...",
  "language": "python",  // optional, auto-detected if not provided
  "max_file_lines": 300,  // optional, default 300
  "max_function_lines": 50  // optional, default 50
}

Output (stdout JSON):
{
  "metrics": {
    "total_lines": 150,
    "code_lines": 120,
    "blank_lines": 20,
    "comment_lines": 10,
    "functions": 5,
    "classes": 2
  },
  "functions": [
    {"name": "process_data", "lines": 45, "start_line": 10},
    {"name": "validate", "lines": 12, "start_line": 60}
  ],
  "warnings": [
    "Function 'handle_request' is 65 lines (exceeds 50 line limit)",
    "File has 450 total lines (exceeds 300 line limit)"
  ],
  "summary": "5 functions, 2 classes, 150 lines. 2 warnings."
}
"""

import json
import sys
import re
from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class FunctionInfo:
    name: str
    lines: int
    start_line: int


@dataclass
class Metrics:
    total_lines: int
    code_lines: int
    blank_lines: int
    comment_lines: int
    functions: int
    classes: int


def detect_language(code: str) -> str:
    """Simple language detection based on common patterns."""
    if re.search(r'\bdef\s+\w+\s*\(', code):
        return 'python'
    if re.search(r'\bfunction\s+\w+\s*\(', code) or re.search(r'=>', code):
        return 'javascript'
    if re.search(r'\bfunc\s+\w+\s*\(', code):
        return 'go'
    if re.search(r'\bfn\s+\w+\s*\(', code):
        return 'rust'
    return 'unknown'


def analyze_python(code: str) -> tuple[Metrics, list[FunctionInfo]]:
    """Analyze Python code."""
    lines = code.split('\n')
    total_lines = len(lines)
    blank_lines = sum(1 for line in lines if not line.strip())
    comment_lines = sum(1 for line in lines if line.strip().startswith('#'))
    code_lines = total_lines - blank_lines - comment_lines

    # Find functions
    functions: list[FunctionInfo] = []
    class_count = 0

    # Simple regex-based function detection
    func_pattern = re.compile(r'^(\s*)def\s+(\w+)\s*\(')
    class_pattern = re.compile(r'^class\s+\w+')

    current_func: Optional[tuple[str, int, int]] = None  # (name, start_line, indent)

    for i, line in enumerate(lines, 1):
        # Check for class
        if class_pattern.match(line):
            class_count += 1

        # Check for function start
        func_match = func_pattern.match(line)
        if func_match:
            # Save previous function if exists
            if current_func:
                name, start, indent = current_func
                functions.append(FunctionInfo(
                    name=name,
                    lines=i - start,
                    start_line=start
                ))

            indent_level = len(func_match.group(1))
            func_name = func_match.group(2)
            current_func = (func_name, i, indent_level)

    # Don't forget the last function
    if current_func:
        name, start, indent = current_func
        functions.append(FunctionInfo(
            name=name,
            lines=total_lines - start + 1,
            start_line=start
        ))

    metrics = Metrics(
        total_lines=total_lines,
        code_lines=code_lines,
        blank_lines=blank_lines,
        comment_lines=comment_lines,
        functions=len(functions),
        classes=class_count
    )

    return metrics, functions


def analyze_javascript(code: str) -> tuple[Metrics, list[FunctionInfo]]:
    """Analyze JavaScript/TypeScript code."""
    lines = code.split('\n')
    total_lines = len(lines)
    blank_lines = sum(1 for line in lines if not line.strip())
    comment_lines = sum(1 for line in lines if line.strip().startswith('//') or line.strip().startswith('*'))
    code_lines = total_lines - blank_lines - comment_lines

    # Find functions (simplified)
    functions: list[FunctionInfo] = []
    class_count = len(re.findall(r'\bclass\s+\w+', code))

    # Match function declarations, arrow functions, and methods
    func_patterns = [
        re.compile(r'^\s*(?:async\s+)?function\s+(\w+)\s*\('),
        re.compile(r'^\s*(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:function|\([^)]*\)\s*=>|\w+\s*=>)'),
        re.compile(r'^\s*(\w+)\s*\([^)]*\)\s*\{'),  # method shorthand
    ]

    for i, line in enumerate(lines, 1):
        for pattern in func_patterns:
            match = pattern.match(line)
            if match:
                functions.append(FunctionInfo(
                    name=match.group(1),
                    lines=1,  # Simplified - would need brace matching for accurate count
                    start_line=i
                ))
                break

    metrics = Metrics(
        total_lines=total_lines,
        code_lines=code_lines,
        blank_lines=blank_lines,
        comment_lines=comment_lines,
        functions=len(functions),
        classes=class_count
    )

    return metrics, functions


def analyze_generic(code: str) -> tuple[Metrics, list[FunctionInfo]]:
    """Generic analysis for unknown languages."""
    lines = code.split('\n')
    total_lines = len(lines)
    blank_lines = sum(1 for line in lines if not line.strip())

    metrics = Metrics(
        total_lines=total_lines,
        code_lines=total_lines - blank_lines,
        blank_lines=blank_lines,
        comment_lines=0,
        functions=0,
        classes=0
    )

    return metrics, []


def analyze_code(code: str, language: Optional[str] = None) -> tuple[Metrics, list[FunctionInfo], str]:
    """Analyze code and return metrics."""
    if not language:
        language = detect_language(code)

    if language == 'python':
        metrics, functions = analyze_python(code)
    elif language in ('javascript', 'typescript', 'js', 'ts'):
        metrics, functions = analyze_javascript(code)
    else:
        metrics, functions = analyze_generic(code)

    return metrics, functions, language


def generate_warnings(
    metrics: Metrics,
    functions: list[FunctionInfo],
    max_file_lines: int,
    max_function_lines: int
) -> list[str]:
    """Generate warnings for code quality issues."""
    warnings = []

    if metrics.total_lines > max_file_lines:
        warnings.append(
            f"File has {metrics.total_lines} total lines (exceeds {max_file_lines} line limit)"
        )

    for func in functions:
        if func.lines > max_function_lines:
            warnings.append(
                f"Function '{func.name}' is {func.lines} lines (exceeds {max_function_lines} line limit)"
            )

    return warnings


def main():
    """Main entry point."""
    try:
        # Read input from stdin
        input_data = json.load(sys.stdin)

        code = input_data.get('code', '')
        language = input_data.get('language')
        max_file_lines = input_data.get('max_file_lines', 300)
        max_function_lines = input_data.get('max_function_lines', 50)

        if not code:
            result = {
                'error': 'No code provided. Send {"code": "your code here"}'
            }
            print(json.dumps(result))
            return

        # Analyze
        metrics, functions, detected_language = analyze_code(code, language)
        warnings = generate_warnings(metrics, functions, max_file_lines, max_function_lines)

        # Build summary
        parts = []
        if metrics.functions:
            parts.append(f"{metrics.functions} function{'s' if metrics.functions != 1 else ''}")
        if metrics.classes:
            parts.append(f"{metrics.classes} class{'es' if metrics.classes != 1 else ''}")
        parts.append(f"{metrics.total_lines} lines")
        if warnings:
            parts.append(f"{len(warnings)} warning{'s' if len(warnings) != 1 else ''}")

        summary = ', '.join(parts) + '.'

        # Build result
        result = {
            'language': detected_language,
            'metrics': asdict(metrics),
            'functions': [asdict(f) for f in functions],
            'warnings': warnings,
            'summary': summary
        }

        print(json.dumps(result, indent=2))

    except json.JSONDecodeError as e:
        result = {'error': f'Invalid JSON input: {e}'}
        print(json.dumps(result))
    except Exception as e:
        result = {'error': f'Analysis failed: {e}'}
        print(json.dumps(result))


if __name__ == '__main__':
    main()
